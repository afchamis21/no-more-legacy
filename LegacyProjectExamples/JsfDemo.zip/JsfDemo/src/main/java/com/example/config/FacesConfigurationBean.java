package com.example.config;

import jakarta.faces.annotation.FacesConfig;
import static jakarta.faces.annotation.FacesConfig.Version.JSF_2_3;

/**
 *
 * @author hantsy
 */
@FacesConfig()
public class FacesConfigurationBean {

}
