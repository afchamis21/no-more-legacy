/*!
 * Java REST API
 * Author: Roshan Gade
 * Date: 20/7/18
 */
package com.test.api.framework;

@FunctionalInterface
public interface Task {
    void run();
}
